#pragma once
#include <Entity.h>
#include <SFML/Graphics.hpp>
#include <time.h>

class Asteroid: public Entity
{

    public:
        Asteroid();
        void update();

};

