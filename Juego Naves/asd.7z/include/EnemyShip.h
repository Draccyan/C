#pragma once
#include <Entity.h>
#include <SFML/Graphics.hpp>


class EnemyShip: public Entity
{


    public:
        EnemyShip();
        void update();

};


